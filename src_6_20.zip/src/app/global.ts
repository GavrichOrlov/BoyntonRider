"use strict";

// export const hostApi = "http://letsride.work/";
export const hostApi = "http://localhost:8000/";